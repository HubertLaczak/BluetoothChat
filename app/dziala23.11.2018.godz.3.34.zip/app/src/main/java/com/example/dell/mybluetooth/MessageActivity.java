package com.example.dell.mybluetooth;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public class MessageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()){
            case R.id.item2:
                openActivity2();
                return true;
            case R.id.item3:
                openActivity3();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void openActivity3() {
        Intent intent = new Intent(this, AboutActivity.class);
        startActivity(intent);

    }

    private void openActivity2() {

        Intent intent = new Intent(this, SettingsActivity.class);
        startActivity(intent);
    }
}
